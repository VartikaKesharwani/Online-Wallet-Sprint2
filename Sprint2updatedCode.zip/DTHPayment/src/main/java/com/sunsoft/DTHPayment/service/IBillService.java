package com.sunsoft.DTHPayment.service;


import java.util.List;
import java.util.Optional;

import com.sunsoft.DTHPayment.entity.BillPayment;

public interface IBillService {
	
	public double getBalance(int dthbillId);
	
	public BillPayment getBillInfo(int dthbillId);
	
	public double updateBalance(BillPayment payment);
	
	List<BillPayment> getAllBillPayment();
	
	Optional <BillPayment> findById(int dthbillId);

}
