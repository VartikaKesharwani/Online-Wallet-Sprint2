package com.sunsoft.DTHPayment.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.DTHPayment.entity.BillPayment;
import com.sunsoft.DTHPayment.repository.IBillRepository;



@Service
public class BillService implements IBillService {
	
	@Autowired
	IBillRepository billRepository;
	
	
	
	public List<BillPayment> getAllBillPayment()
	{
		List<BillPayment> allBill=new ArrayList <BillPayment>();
		billRepository.findAll().forEach(b ->allBill.add(b));
		return allBill;
	}
	
	
	@Override
	public double getBalance(int dthbillId) {
		double balance = 0;
		try {
			balance = billRepository.findById(dthbillId).get().getWalletBalance();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return balance;
	}

	@Override
	public BillPayment getBillInfo(int dthbillId) {
		BillPayment accountDetails = null;
		try {
			accountDetails = billRepository.findById(dthbillId).get();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return accountDetails;
	}
	
	
	@Override
	public double updateBalance(BillPayment payment) {
		double totalBalance = 0;
		try {
			billRepository.save(payment);
			totalBalance = this.getBalance(payment.getDthbillId());
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return totalBalance;
	}


	@Override
	
	public Optional<BillPayment> findById(int dthbillId)
	{
		return billRepository.findById(dthbillId);
	}

}
