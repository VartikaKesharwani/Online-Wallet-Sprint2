package com.sunsoft.DTHPayment.entity;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dthaccount")
public class BillPayment {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name="dthbillId")
	 int dthbillId;
	
	 
	@Column(name="customerName")
	 String customerName;
	 
	 @Column(name="phoneNo")
	 BigInteger phoneNo;
	 
	 @Column(name="walletBalance")
	 double walletBalance;
	 
	  @Column(name="walletaccountId")
	   private int walletaccountId;
		 
	 
	 public BillPayment(){
		}
	 
	 public BillPayment(int dthbillId,String customerName,BigInteger phoneNo,double walletBalance,int walletaccountId) {
		 super();
		 this.dthbillId=dthbillId;
		 this.customerName=customerName;
		 this.walletBalance=walletBalance;
		 this.phoneNo=phoneNo;
		 this.walletaccountId=walletaccountId;
		
		 
	 }
	 public int getDthbillId() {
			return dthbillId;
		}

		public void setDthbillId(int dthbillId) {
			this.dthbillId = dthbillId;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		
		public double getWalletBalance() {
			return walletBalance;
		}

		public void setWalletBalance(double walletBalance) {
			this.walletBalance = walletBalance;
		}

		public int getWalletaccountId() {
			return walletaccountId;
		}

		public void setWalletaccountId(int walletaccountId) {
			this.walletaccountId = walletaccountId;
		}
		
		public BigInteger getPhoneNo() {
			return phoneNo;
		}

		public void setPhoneNo(BigInteger phoneNo) {
			this.phoneNo = phoneNo;
		}


	



}
