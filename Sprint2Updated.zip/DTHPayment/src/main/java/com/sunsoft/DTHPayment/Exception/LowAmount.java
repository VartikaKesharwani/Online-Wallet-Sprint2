package com.sunsoft.DTHPayment.Exception;

public class LowAmount extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LowAmount(String str)
	{
		super(str);
	}
	

}
