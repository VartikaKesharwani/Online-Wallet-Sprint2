package com.sunsoft.DTHPayment.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="dthaccount")
public class BillPayment {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 @Column(name="dthbillId")
	 int dthbillId;
	
	 @Column(name="customerName")
	 String customerName;
	 
	 @Column(name="noOfSubscribedChannel")
	 private int noOfSubscribedChannel;
	 
	 @Column(name="walletBalance")
	 double walletBalance;
	 
	  @Column(name="walletaccountId")
	   private int walletaccountId;
		 
	 
	 public BillPayment(){
		}
	 
	 public BillPayment(int dthbillId,String customerName,int noOfSubscribedChannel,double walletBalance,int walletaccountId) {
		 super();
		 this.dthbillId=dthbillId;
		 this.customerName=customerName;
		 this.walletBalance=walletBalance;
		 this.noOfSubscribedChannel=noOfSubscribedChannel;
		 this.walletaccountId=walletaccountId;
		
		 
	 }
	 public int getDthbillId() {
			return dthbillId;
		}

		public void setDthbillId(int dthbillId) {
			this.dthbillId = dthbillId;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public int getNoOfSubscribedChannel() {
			return noOfSubscribedChannel;
		}

		public void setNoOfSubscribedChannel(int noOfSubscribedChannel) {
			this.noOfSubscribedChannel = noOfSubscribedChannel;
		}

		public double getWalletBalance() {
			return walletBalance;
		}

		public void setWalletBalance(double walletBalance) {
			this.walletBalance = walletBalance;
		}

		public int getWalletaccountId() {
			return walletaccountId;
		}

		public void setWalletaccountId(int walletaccountId) {
			this.walletaccountId = walletaccountId;
		}

	



}
