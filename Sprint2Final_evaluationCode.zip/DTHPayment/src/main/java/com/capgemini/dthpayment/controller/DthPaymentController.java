package com.capgemini.dthpayment.controller;

import java.util.List;
import java.util.Optional;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.dthpayment.entity.DthPayment;
import com.capgemini.dthpayment.service.DthPaymentServiceImpl;


@RestController
@CrossOrigin(origins="http://localhost:4200")

@RequestMapping("bill/payment")

public class DthPaymentController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	 DthPaymentServiceImpl billService;
	
	
	@GetMapping("/payMoney/{dthbillId}/{amount}")
	public double payMoney(@PathVariable int dthbillId, @PathVariable double amount) {
		double finalBalance=0;
			try {
			DthPayment payment = billService.getBillInfo(dthbillId);
			double currentBalance = payment.getWalletBalance();
			finalBalance  = currentBalance - amount;
			payment.setWalletBalance(finalBalance);
			finalBalance = billService.updateBalance(payment);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return finalBalance;
			
	
	}
	
	
	@RequestMapping("/getCustomerList")
	public List<DthPayment> bills()
	{
	
		return billService.getAllBillPayment();
		
	}
	
	
	@RequestMapping(value="/getBillInfo/{dthbillId}",method=RequestMethod.GET)
	public DthPayment getBill(@PathVariable("dthbillId") int dthbillId)
	{
		
		Optional<DthPayment> bill=billService.findById(dthbillId);
		
		DthPayment billpay=bill.get();
		
		return billpay;
		
		
	}
	



}
