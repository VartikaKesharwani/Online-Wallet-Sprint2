package com.capgemini.dthpayment.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dthpayment.entity.DthPayment;
import com.capgemini.dthpayment.repository.IDthPaymentRepository;



@Service
public class DthPaymentServiceImpl implements IDthPaymentService {
	
	@Autowired
	IDthPaymentRepository billRepository;
	
	
	
	public List<DthPayment> getAllBillPayment()
	{
		List<DthPayment> allBill=new ArrayList <DthPayment>();
		billRepository.findAll().forEach(bill ->allBill.add(bill));
		return allBill;
	}
	
	
	@Override
	public double getBalance(int dthbillId) {
		double balance = 0;
		try {
			balance = billRepository.findById(dthbillId).get().getWalletBalance();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return balance;
	}

	@Override
	public DthPayment getBillInfo(int dthbillId) {
		DthPayment accountDetails = null;
		try {
			accountDetails = billRepository.findById(dthbillId).get();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return accountDetails;
	}
	
	
	@Override
	public double updateBalance(DthPayment payment) {
		double totalBalance = 0;
		try {
			billRepository.save(payment);
			totalBalance = this.getBalance(payment.getDthbillId());
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		return totalBalance;
	}


	@Override
	
	public Optional<DthPayment> findById(int dthbillId)
	{
		return billRepository.findById(dthbillId);
	}

}
