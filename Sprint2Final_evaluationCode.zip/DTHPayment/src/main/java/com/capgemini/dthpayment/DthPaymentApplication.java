package com.capgemini.dthpayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DthPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DthPaymentApplication.class, args);
	}

}
