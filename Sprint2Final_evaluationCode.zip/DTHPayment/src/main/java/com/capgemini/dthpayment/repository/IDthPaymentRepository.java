package com.capgemini.dthpayment.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.dthpayment.entity.DthPayment;



@Repository("billRepository")
public interface IDthPaymentRepository extends JpaRepository<DthPayment, Integer> {

}
