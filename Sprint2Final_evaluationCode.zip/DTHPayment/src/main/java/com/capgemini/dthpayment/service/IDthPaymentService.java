package com.capgemini.dthpayment.service;


import java.util.List;
import java.util.Optional;

import com.capgemini.dthpayment.entity.DthPayment;

public interface IDthPaymentService {
	
	public double getBalance(int dthbillId);
	
	public DthPayment getBillInfo(int dthbillId);
	
	public double updateBalance(DthPayment payment);
	
	List<DthPayment> getAllBillPayment();
	
	Optional <DthPayment> findById(int dthbillId);

}
