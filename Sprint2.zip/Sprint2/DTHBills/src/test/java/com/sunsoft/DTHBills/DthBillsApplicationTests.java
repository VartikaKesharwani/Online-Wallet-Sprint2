package com.sunsoft.DTHBills;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DthBillsApplicationTests {

	@Test
	void contextLoads() {
	}

}
