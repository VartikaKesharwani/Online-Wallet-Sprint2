package com.sunsoft.DTHBills.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.DTHBills.entity.BillPayment;
import com.sunsoft.DTHBills.repository.IBillRepository;

@Service
public class BillService implements IBillService {
	
	@Autowired
	IBillRepository billRepository;
	
	public BillPayment payDthBill(BillPayment payment)
	{
		int flag=0;
		try
		{
			billRepository.save(payment);
			flag=1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return payment;
	}
	
	public List<BillPayment> getAllBillPayment()
	{
		List<BillPayment> allBill=new ArrayList <BillPayment>();
		billRepository.findAll().forEach(b ->allBill.add(b));
		return allBill;
	}

	
	public BillPayment addCustomer(BillPayment bill)
	{
		 return billRepository.save(bill);
	}

	@Override
	
	public Optional<BillPayment> findById(int customerid)
	{
		return billRepository.findById(customerid);
	}
	
	
	
	
	

}
