package com.sunsoft.DTHBills.service;


import java.util.List;
import java.util.Optional;

import com.sunsoft.DTHBills.entity.BillPayment;

public interface IBillService {
	 
	List<BillPayment> getAllBillPayment();
	public BillPayment addCustomer(BillPayment bill);
	Optional<BillPayment> findById(int customerid);
	public BillPayment payDthBill(BillPayment payment);
}
