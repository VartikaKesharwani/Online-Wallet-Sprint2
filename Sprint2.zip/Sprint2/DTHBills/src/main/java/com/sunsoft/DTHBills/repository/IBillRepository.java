package com.sunsoft.DTHBills.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sunsoft.DTHBills.entity.BillPayment;

@Repository("billRepository")
public interface IBillRepository extends CrudRepository<BillPayment, Integer> {

	

}
