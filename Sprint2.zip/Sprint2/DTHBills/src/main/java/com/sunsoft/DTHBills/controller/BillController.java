package com.sunsoft.DTHBills.controller;


import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.DTHBills.entity.BillPayment;
import com.sunsoft.DTHBills.service.BillService;

@RestController
@RequestMapping("payment/list/v1")
public class BillController {
	
	@Autowired
	BillService billService;
	
	
	@RequestMapping(value="/pay",method=RequestMethod.GET)
	public ResponseEntity<String> saveCustomer()
	{
		BillPayment payment=new BillPayment();
		payment.setAmountpay(400);
		payment.setCustomerphno(9854);
		try {
			billService.payDthBill(payment);
		}
		catch(Exception e)
		{
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>("Amount Paid",HttpStatus.CREATED);
		
	}
	
	@RequestMapping("")
	public List<BillPayment> bills()
	{
	
		
		return billService.getAllBillPayment();
		
	}
	
	
	@RequestMapping(value="/{customerid}",method=RequestMethod.GET)
	public BillPayment getBill(@PathVariable("customerid") int customerid)
	{
		Optional<BillPayment> bill=billService.findById(customerid);
		
		BillPayment billpay=bill.get();
		return billpay;
		
	}
	
	
	
	
	@RequestMapping(value="",method=RequestMethod.POST)
	@ResponseStatus(value=HttpStatus.CREATED)
	public void addCustomer(@RequestBody BillPayment bill){
		billService.addCustomer(bill);
		
	}
	
	

}
