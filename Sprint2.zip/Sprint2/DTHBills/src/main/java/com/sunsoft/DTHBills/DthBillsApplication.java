
package com.sunsoft.DTHBills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DthBillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DthBillsApplication.class, args);
	}

}
