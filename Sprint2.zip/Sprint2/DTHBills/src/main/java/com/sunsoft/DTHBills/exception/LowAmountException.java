package com.sunsoft.DTHBills.exception;

public class LowAmountException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public LowAmountException(String str)
	{
		super(str);
	}

}
