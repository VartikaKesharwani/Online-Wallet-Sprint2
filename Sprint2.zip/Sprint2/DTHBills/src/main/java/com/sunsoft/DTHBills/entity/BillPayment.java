package com.sunsoft.DTHBills.entity;
 

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
 @Entity
 @Table(name="dthbilling")
public class BillPayment {
	 @Id
	 @Column(name="customerId")
	 private int customerid;
	
	 @Column(name="customerName")
	 String customername;
	 
	 @Column(name="customerPhno")
	 private int customerphno;
	 
	 @Column(name="amountPay")
	 private int amountpay;
	 
	 @Column(name="subscribedChannel")
	 String subscribedchannel;


	
	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public int getCustomerphno() {
		return customerphno;
	}

	public void setCustomerphno(int customerphno) {
		this.customerphno = customerphno;
	}

	public int getAmountpay() {
		return amountpay;
	}

	public void setAmountpay(int amountpay) {
		this.amountpay = amountpay;
	}

	public String getSubscribedchannel() {
		return subscribedchannel;
	}

	public void setSubscribedchannel(String subscribedchannel) {
		this.subscribedchannel = subscribedchannel;
	}

	public BillPayment()
	{
		super();
	}

	public String toString()
	{
	 
	 return "bill[customerId="+ customerid +",customerName="+customername+",customerPhno="+customerphno+", "
	 		+ "amountPay="+amountpay+",subscribedChannel="+subscribedchannel+"]";
	 
	}
	

}
